
function Name1(){
    var name="shreya";
    var fun=()=>{return "Hello from react";};
    return(
        <div>
            <h1>pawar {name}.....{fun()}</h1>
        </div>
    );
}
export default Name1;