
import Logic from './Logic';
import './App.css';


function App() {
  return (
    <div>
    <Logic/>
    </div>
  );
}

export default App;
