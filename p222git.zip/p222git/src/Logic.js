import React,{useState} from "react";
import Account from "./Account";

function Logic(){
    const persons = [
  {
    name: "Amit Sharma",
    image: "https://static.vecteezy.com/system/resources/thumbnails/033/129/417/small/a-business-man-stands-against-white-background-with-his-arms-crossed-ai-generative-photo.jpg",
    salary: 850000,
    description: "Full Stack Developer skilled in React and Node.js",
    experience: "5 years"
  },
  {
    name: "Neha Verma",
    image: "https://img.freepik.com/free-photo/brunette-business-woman-with-wavy-long-hair-blue-eyes-stands-holding-notebook-hands_197531-343.jpg?semt=ais_hybrid&w=740&q=80",
    salary: 950000,
    description: "Frontend Developer with strong UI/UX knowledge",
    experience: "6 years"
  },
  {
    name: "Rahul Singh",
    image: "https://static.vecteezy.com/system/resources/thumbnails/033/131/906/small/a-business-man-stands-against-white-background-with-his-arms-crossed-ai-generative-photo.jpg",
    salary: 1200000,
    description: "Backend Developer specialized in Java and Spring Boot",
    experience: "8 years"
  },
  {
    name: "Pooja Patel",
    image: "https://market-resized.envatousercontent.com/photodune.net/EVA/TRX/cd/5b/4b/f0/98/v1_E10/E109CFC6.jpg?auto=format&q=94&mark=https%3A%2F%2Fassets.market-storefront.envato-static.com%2Fwatermarks%2Fphoto-260724.png&opacity=0.2&cf_fit=contain&w=590&h=917&s=88ec8e631230e6354d815c98ffc3ce4a152ce8f61c75d93da4c3df6aeaf9801b",
    salary: 700000,
    description: "Junior Web Developer with HTML, CSS, and JavaScript skills",
    experience: "2 years"
  },
  {
    name: "Karan Mehta",
    image: "https://img.freepik.com/free-photo/smiling-young-male-professional-standing-with-arms-crossed-while-making-eye-contact-against-isolated-background_662251-838.jpg",
    salary: 1500000,
    description: "DevOps Engineer experienced in AWS and Docker",
    experience: "9 years"
  },
  {
    name: "Sneha Iyer",
    image: "https://t4.ftcdn.net/jpg/09/69/34/27/360_F_969342778_BCPcWUTyPG7RsXUUPaJ2jDNiiCzrtyOd.jpg",
    salary: 1100000,
    description: "Data Analyst with strong Python and SQL background",
    experience: "7 years"
  },
  {
    name: "Vikas Rao",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTB80oGT-BRYfSKgfCzbWUTfc5ZeRC4kvJ6GA&s",
    salary: 1800000,
    description: "AI/ML Engineer working on predictive models",
    experience: "10 years"
  },
  {
    name: "Anjali Deshmukh",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSEMaMbQetoc3cAJFnZCH6gFFGMFa14NCr-Q&s",
    salary: 900000,
    description: "Software Tester skilled in automation testing",
    experience: "5 years"
  },
  {
    name: "Rohit Kumar",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQY9b_u54JNRxi87Sk4eVhIzrB3B8AJAWMNqw&s",
    salary: 1300000,
    description: "Mobile App Developer (Android & iOS)",
    experience: "8 years"
  },
  {
    name: "Priya Nair",
    image: "https://us.images.westend61.de/0001564640pw/beautiful-smiling-young-female-professional-with-brown-hair-in-office-DIGF15466.jpg",
    salary: 1000000,
    description: "Cloud Engineer with Azure certification",
    experience: "6 years"
  }
];
   var [i,setI]=useState(0);
   var next=()=>{
    setI(i+1);
   }
   var prev=()=>{
    if(i===0){
      setI(persons.length-1);
    }
      setI((i-1));
    
   };
   return (
    <div>
    <Account name={persons[i].name} salary={persons[i].salary} description={persons[i].description } experience={persons[i].experience} image={persons[i].image}></Account>
    <button onClick={prev}>Previous</button>
    <button onClick={next}>Next</button>
    </div>


   )

}
export default Logic;