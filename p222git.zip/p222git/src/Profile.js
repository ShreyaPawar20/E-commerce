import './Profile.css';
function Profile(){
    const employee=[
        {
            ename:"karuna",
            imglink:"",
            description:"HHHH",
            experience:2
            
        },
         {
            ename:"Yash",
            imglink:"",
            description:"HHHH",
            experience:"I have 6 years of experience"
            
        },
         {
            ename:"Sahil",
            imglink:"",
            description:"I am a certified AI expert",
            experience:"I have 3 years of experience"
            
        },
         {
            ename:"Aman",
            imglink:"",
            description:"I am a full stack python developer",
            experience:"I have 10 years of experience"
            
        },
         {
            ename:"Rutuja",
            imglink:"",
            description:"I am a full stack java developer",
            experience:"I have 5 years years of experience"
            
        }
    ];
    return(
        <div>
            <h1>Hello from profile</h1>
        <div>
        {employee.map((emp)=>{return(
            <div className="card">
            <img src={emp.imglink} className="i"/>
            <h1>{emp.ename}</h1>
            <h2>{emp.experience}</h2>
            <p>{emp.description}</p>
            </div>

        )

        
            
        })}
        </div>
        </div>
    )
}
export default Profile;