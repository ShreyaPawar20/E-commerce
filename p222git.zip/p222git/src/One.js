import { useState } from "react";
function One(){
    var [name,setName]=useState("Sanket"); 
    var [num,setNum]=useState(10);
    var change=()=>{
        setName("Gaurav");
    }
    var change2=()=>{
        setNum(num+10);

    }
    var [boolean,setboolean]=useState("True");
    var change=()=>{
        setboolean("False");
    }

    var [number,setNumber]=useState(1);
    var change1=()=>{
        setNumber(number*2);
    }

    var [color,setColor]=useState("red");
    var change4=()=>{
        setColor("green");
    }

    var [emp,setEmp]=useState({id:1,ename:"Karuna",city:"Jalgaon"});
    var change5=()=>{
        setEmp({id:2,ename:"Tanu",city:"Nagpur"});
    }

    
    var [box,setBox]=useState({height:"300px",width:"500px",backgroundColor:"yellow"})
    var change6=()=>{
        setBox({height:"500px",width:"800px",backgroundColor:"pink",borderRadius:"50%"});
    }
    return(
        <div>
            <h1>Hello from One {name}</h1>
            <button onClick={change}>Change</button>
           
            <h1>{num}</h1>
            <button onClick={change2}>Change Number</button>
             <h1>{number}</h1>
            <button onClick={change1}>Change Number</button>
           
            <div style={{height:"300px",width:"200px",backgroundColor:color}}>Hello</div>
            <button onClick={change4}>Change Color</button>
            <h2>{emp.id}</h2>
            <h2>{emp.ename}</h2>
            <h2>{emp.city}</h2>
            <button onClick={change5}>Change employee</button>

             <div style={box}>Hello</div>
              <button onClick={change6}>Change shape</button>

          
            
        </div>
    );
}
export default One;