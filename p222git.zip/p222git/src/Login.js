import './Login.css';

function Login() {
  return (
    <div className="main-page">
      
      <div className="container">
        <h1>Login</h1>
        <input type="email" placeholder="Email" />
        <br /><br />
        <input type="password" placeholder="Password" />
        <br /><br />
        <button onClick={() => alert("Logging in...")}>Login</button>
      </div>

    
      <div className="container">
        <h1>Sign Up</h1>
        <input type="text" placeholder="Full Name" />
        <br /><br />
        <input type="email" placeholder="Email" />
        <br /><br />
        <input type="password" placeholder="Create Password" />
        <br /><br />
        <button onClick={() => alert("Registering...")}>Register</button>
      </div>

    </div>
  );
}

export default Login;