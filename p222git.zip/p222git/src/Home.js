
function Home(){
    var comp="Home...";
    var x=300;
    var name="Krishna";
    var name2="Ram";
    var isTrue=true;
    var fun=()=>{return "Hello from fun....";};
    return(
        <div>
            <h1>Hare {name}.....{fun()}</h1>
            <h2>Hare {name2}.....</h2>
            <h1>Helo from {comp}</h1>
        </div>
    );


};
export default Home;
